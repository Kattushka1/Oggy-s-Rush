import pygame
import sys
# ВАЖЛИВО: Імпортуємо константи з constanta.py
from constanta import (
    WHITE, BLACK, GRAY, DARK_GRAY, BLUE, GREEN, RED,
    BUTTON_IMAGE_NORMAL, BUTTON_IMAGE_HOVER, BUTTON_IMAGE_PRESSED,
    BUTTON_TEXT_COLOR, BUTTON_SHADOW_COLOR, BUTTON_BORDER_RADIUS,
    BUTTON_SHADOW_OFFSET, BUTTON_CLICK_OFFSET,
    SCREEN_WIDTH, SCREEN_HEIGHT, # Додано для використання в draw_button
    BACKGROUND_SETTINGS_IMAGE # Додано для фону налаштувань
)

# --- Шрифти ---
pygame.font.init()
font = pygame.font.Font(None, 50)
small_font = pygame.font.Font(None, 30)

# --- Допоміжні функції для малювання тексту та кнопок ---
def draw_text(screen, text, font_obj, color, x, y, center=False):
    text_surface = font_obj.render(text, True, color)
    text_rect = text_surface.get_rect()
    if center:
        text_rect.center = (x, y)
    else:
        text_rect.topleft = (x, y)
    screen.blit(text_surface, text_rect)
    return text_rect

# ОНОВЛЕНА ФУНКЦІЯ draw_button (для menu.py)
def draw_button(screen, text, font_obj, x, y, width, height, normal_image_url, hover_image_url, pressed_image_url):
    button_rect = pygame.Rect(x, y, width, height)
    mouse_pos = pygame.mouse.get_pos()
    clicked = pygame.mouse.get_pressed()[0]

    current_image = None
    text_offset_y = 0 # Зміщення тексту для ефекту натискання

    is_hovering = button_rect.collidepoint(mouse_pos)
    
    try:
        if is_hovering:
            if clicked:
                current_image = pygame.image.load(pressed_image_url).convert_alpha()
                text_offset_y = BUTTON_CLICK_OFFSET # Зміщуємо текст вниз при натисканні
            else:
                current_image = pygame.image.load(hover_image_url).convert_alpha()
        else:
            current_image = pygame.image.load(normal_image_url).convert_alpha()
        
        # Масштабуємо зображення під розмір кнопки
        current_image = pygame.transform.scale(current_image, (width, height))
        
        # Якщо кнопка натиснута, зміщуємо її трохи вниз для візуального ефекту
        if is_hovering and clicked:
            screen.blit(current_image, (button_rect.x + BUTTON_CLICK_OFFSET, button_rect.y + BUTTON_CLICK_OFFSET))
        else:
            screen.blit(current_image, button_rect)

    except pygame.error as e:
        print(f"Помилка завантаження зображення кнопки: {e}. Використовую резервний колір.")
        # Резервний варіант, якщо зображення не завантажилось
        current_color = BUTTON_IMAGE_NORMAL
        if is_hovering:
            current_color = BUTTON_IMAGE_HOVER
            if clicked:
                current_color = BUTTON_IMAGE_PRESSED
                text_offset_y = BUTTON_CLICK_OFFSET
        pygame.draw.rect(screen, current_color, button_rect, border_radius=BUTTON_BORDER_RADIUS)
        # Малюємо тінь, якщо використовується резервний колір
        shadow_rect = pygame.Rect(x + BUTTON_SHADOW_OFFSET, y + BUTTON_SHADOW_OFFSET, width, height)
        pygame.draw.rect(screen, BUTTON_SHADOW_COLOR, shadow_rect, border_radius=BUTTON_BORDER_RADIUS)


    # Малюємо текст кнопки поверх зображення
    draw_text(screen, text, font_obj, BUTTON_TEXT_COLOR, button_rect.centerx, button_rect.centery + text_offset_y, center=True)
    
    return button_rect, is_hovering and clicked

# --- Функція для отримання перекладеного тексту (буде імпортуватися з main.py) ---
# Ця функція тут лише для того, щоб menu.py міг її використовувати для перекладів
# Вона буде перезаписана при імпорті з main.py
def get_translation(lang_key, text_id, translations_dict):
    return text_id # Заглушка, реальна функція буде імпортована

# --- Функція меню налаштувань ---
def run_menu(screen, initial_volume, initial_language, languages_list, translations_dict):
    # ВАЖЛИВО: Імпортуємо get_translation з main.py тут, щоб вона використовувала глобальний TRANSLATIONS
    # Це дозволяє уникнути циклічного імпорту на верхньому рівні
    from main import get_translation, TRANSLATIONS # <--- ВАЖЛИВО: імпортуємо тут

    current_volume = initial_volume
    current_language = initial_language
    languages = languages_list

    options_running = True
    dragging_volume = False

    # Завантаження фонового зображення для налаштувань
    background_image = None
    try:
        background_image = pygame.image.load(BACKGROUND_SETTINGS_IMAGE).convert()
        background_image = pygame.transform.scale(background_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
    except pygame.error as e:
        print(f"Помилка завантаження фону налаштувань: {e}. Використовую резервний колір.")
        background_image = None

    while options_running:
        # Малюємо фон
        if background_image:
            screen.blit(background_image, (0, 0))
        else:
            screen.fill(DARK_GRAY) # Резервний колір, якщо зображення не завантажилось


        # Отримуємо переклади для поточного екрану налаштувань
        translated_settings_title = get_translation(current_language, "settings_title", TRANSLATIONS)
        translated_volume_label = get_translation(current_language, "volume_label", TRANSLATIONS)
        translated_language_label = get_translation(current_language, "language_label", TRANSLATIONS)
        translated_back_button = get_translation(current_language, "back_button", TRANSLATIONS)

        draw_text(screen, translated_settings_title, font, WHITE, SCREEN_WIDTH // 2, 50, center=True)

        # Гучність
        draw_text(screen, f"{translated_volume_label}: {int(current_volume * 100)}%", small_font, WHITE, 100, 150)
        slider_x = 250
        slider_y = 160
        slider_width = 300
        slider_height = 20
        slider_rect = pygame.Rect(slider_x, slider_y, slider_width, slider_height)
        pygame.draw.rect(screen, GRAY, slider_rect)

        handle_x = slider_x + int(current_volume * slider_width) - 10
        handle_y = slider_y - 5
        handle_width = 20
        handle_height = 30
        handle_rect = pygame.Rect(handle_x, handle_y, handle_width, handle_height)
        pygame.draw.rect(screen, BLUE, handle_rect)

        # Мова: відображаємо назву поточної мови, перекладену на поточну мову інтерфейсу
        display_current_language_name = get_translation(current_language, current_language, TRANSLATIONS)
        draw_text(screen, f"{translated_language_label}: {display_current_language_name}", small_font, WHITE, 100, 250)


        # Кнопки для зміни мови (використовуємо стилізовані кнопки)
        prev_lang_button_rect, _ = draw_button(screen, "<", small_font, 300, 240, 50, 40, BUTTON_IMAGE_NORMAL, BUTTON_IMAGE_HOVER, BUTTON_IMAGE_PRESSED)
        next_lang_button_rect, _ = draw_button(screen, ">", small_font, 450, 240, 50, 40, BUTTON_IMAGE_NORMAL, BUTTON_IMAGE_HOVER, BUTTON_IMAGE_PRESSED)

        # Кнопка "Назад"
        back_button_rect, _ = draw_button(screen, translated_back_button, font, SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT - 100, 200, 60, BUTTON_IMAGE_NORMAL, BUTTON_IMAGE_HOVER, BUTTON_IMAGE_PRESSED)

        # --- Обробка подій ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if handle_rect.collidepoint(event.pos):
                        dragging_volume = True

                    if prev_lang_button_rect.collidepoint(event.pos):
                        lang_index = languages.index(current_language)
                        current_language = languages[(lang_index - 1) % len(languages)]
                    if next_lang_button_rect.collidepoint(event.pos):
                        lang_index = languages.index(current_language)
                        current_language = languages[(lang_index + 1) % len(languages)]
                    
                    if back_button_rect.collidepoint(event.pos):
                        options_running = False

            if event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    dragging_volume = False

            if event.type == pygame.MOUSEMOTION:
                if dragging_volume:
                    mouse_x, _ = event.pos
                    new_volume = (mouse_x - slider_x) / slider_width
                    current_volume = max(0.0, min(1.0, new_volume))
                    pygame.mixer.music.set_volume(current_volume)

        pygame.display.flip()

    return current_volume, current_language