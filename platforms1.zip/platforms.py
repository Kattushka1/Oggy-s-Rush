# platforms.py

import pygame
from constanta import * # Імпортуємо всі константи з constanta.py

class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        super().__init__()
        self.image = pygame.Surface((width, height))
        self.image.fill(BROWN) # Колір платформи
        self.rect = self.image.get_rect(topleft=(x, y))

    def update(self, dx): # Оновлення позиції з урахуванням зсуву екрану
        self.rect.x += dx 
    def draw(self, screen):
        screen.blit(self.image, self.rect)