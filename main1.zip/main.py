import pygame
import sys
import random
import os

# Змінюємо робочу директорію на папку з грою
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)

# ВАЖЛИВО: Імпортуємо всі константи з constanta.py
from constanta import *

# ВАЖЛИВО: Імпортуємо класи з character.py та platforms.py
from character import Player, Enemy
from platforms import Platform

# Імпортуємо run_menu з menu.py
from menu import run_menu

from music import AudioManager

# --- Ініціалізація Pygame ---
pygame.init()
pygame.font.init()
pygame.mixer.init()

# --- Налаштування екрану ---
SCREEN = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Platformer Rush")

# --- Ініціалізація та використання AudioManager ---
audio_manager = AudioManager()

# Перевіряємо чи існує музичний файл перед завантаженням
if os.path.exists(MUSIC_FILE):
    # Тепер використовуємо константу MUSIC_FILE з constanta.py
    if not audio_manager.load_music(MUSIC_FILE):
        print(f"!!! ПОПЕРЕДЖЕННЯ: Не вдалося завантажити музику '{MUSIC_FILE}'. Гра продовжиться без неї. !!!")
    else:
        print(f"Музика '{MUSIC_FILE}' завантажена успішно.")
        audio_manager.set_music_volume(0.5) # 50% гучності
        audio_manager.play_music(-1) # Відтворення музики нескінченно
else:
    print(f"Музичний файл '{MUSIC_FILE}' не знайдено. Гра працюватиме без музики.")


# --- Шрифти ---
FONT = pygame.font.Font(None, 50)
SMALL_FONT = pygame.font.Font(None, 30)


# --- ГЛОБАЛЬНИЙ СЛОВНИК ПЕРЕКЛАДІВ ---
TRANSLATIONS = {
    "Українська": {
        "game_title": "Platformer Rush",
        "start_game_button": "Почати гру",
        "options_button": "Налаштування",
        "exit_button": "Вийти",
        "game_running_message": "Гра запущена! (Натисніть ESC для виходу)",
        "settings_title": "Налаштування",
        "volume_label": "Гучність",
        "language_label": "Мова",
        "back_button": "Назад",
        "Українська": "Українська",
        "English": "Англійська",
        "Русский": "Російська",
        "Polski": "Польська",
        "Deutsch": "Німецька",
        "Français": "Французька",
        "Español": "Іспанська",
        "Italiano": "Італійська",
        "中文": "Китайська",
        "日本語": "Японська",
        "Tiếng Việt": "В'єтнамська",
        "हिन्दी": "Гінді",
        "game_over_title": "ГРА ЗАКІНЧЕНА",
        "restart_button": "Знову",
        "return_to_menu_button": "Повернутись до меню",
        "score_label": "Рахунок"
    },
    "English": {
        "game_title": "Platformer Rush",
        "start_game_button": "Start Game",
        "options_button": "Options",
        "exit_button": "Exit",
        "game_running_message": "Game Running! (Press ESC to exit)",
        "settings_title": "Settings",
        "volume_label": "Volume",
        "language_label": "Language",
        "back_button": "Back",
        "Українська": "Ukrainian",
        "English": "English",
        "Русский": "Russian",
        "Polski": "Polish",
        "Deutsch": "German",
        "Français": "French",
        "Español": "Spanish",
        "Italiano": "Italian",
        "中文": "Chinese",
        "日本語": "Japanese",
        "Tiếng Việt": "Vietnamese",
        "हिन्दी": "Hindi",
        "game_over_title": "GAME OVER",
        "restart_button": "Again",
        "return_to_menu_button": "Return to Menu",
        "score_label": "Score"
    },
    "Русский": {
        "game_title": "Платформер Раш",
        "start_game_button": "Начать игру",
        "options_button": "Настройки",
        "exit_button": "Выйти",
        "game_running_message": "Игра запущена! (Нажмите ESC для выхода)",
        "settings_title": "Настройки",
        "volume_label": "Громкость",
        "language_label": "Язык",
        "back_button": "Назад",
        "Українська": "Украинский",
        "English": "Английский",
        "Русский": "Русский",
        "Polski": "Польский",
        "Deutsch": "Немецкий",
        "Français": "Французский",
        "Español": "Испанский",
        "Italiano": "Итальянский",
        "中文": "Китайский",
        "日本語": "Японский",
        "Tiếng Việt": "Вьетнамский",
        "हिन्दी": "Хинди",
        "game_over_title": "ИГРА ОКОНЧЕНА",
        "restart_button": "Снова",
        "return_to_menu_button": "Вернуться в меню",
        "score_label": "Счет"
    },
    "Polski": {
        "game_title": "Platformer Rush",
        "start_game_button": "Rozpocznij Grę",
        "options_button": "Ustawienia",
        "exit_button": "Wyjście",
        "game_running_message": "Gra działa! (Naciśnij ESC, aby wyjść)",
        "settings_title": "Ustawienia",
        "volume_label": "Głośność",
        "language_label": "Język",
        "back_button": "Wstecz",
        "Українська": "Ukraiński",
        "English": "Angielski",
        "Русский": "Rosyjski",
        "Polski": "Polski",
        "Deutsch": "Niemiecki",
        "Français": "Francuski",
        "Español": "Hiszpański",
        "Italiano": "Włoski",
        "中文": "Chiński",
        "日本語": "Japoński",
        "Tiếng Việt": "Wietnamski",
        "हिन्दी": "Hindi",
        "game_over_title": "KONIEC GRY",
        "restart_button": "Jeszcze raz",
        "return_to_menu_button": "Wróć do menu",
        "score_label": "Wynik"
    },
    "Deutsch": {
        "game_title": "Platformer Rush",
        "start_game_button": "Spiel Starten",
        "options_button": "Optionen",
        "exit_button": "Beenden",
        "game_running_message": "Spiel läuft! (Drücke ESC zum Beenden)",
        "settings_title": "Optionen",
        "volume_label": "Lautstärke",
        "language_label": "Sprache",
        "back_button": "Zurück",
        "Українська": "Ukrainisch",
        "English": "Englisch",
        "Русский": "Russisch",
        "Polski": "Polnisch",
        "Deutsch": "Deutsch",
        "Français": "Französisch",
        "Español": "Spanisch",
        "Italiano": "Italienisch",
        "中文": "Chinesisch",
        "日本語": "Japanisch",
        "Tiếng Việt": "Vietnamesisch",
        "हिन्दी": "Hindi",
        "game_over_title": "SPIEL VORBEI",
        "restart_button": "Nochmal",
        "return_to_menu_button": "Zurück zum Menü",
        "score_label": "Punkte"
    },
    "Français": {
        "game_title": "Platformer Rush",
        "start_game_button": "Démarrer le Jeu",
        "options_button": "Options",
        "exit_button": "Quitter",
        "game_running_message": "Jeu en cours ! (Appuyez sur ESC pour quitter)",
        "settings_title": "Options",
        "volume_label": "Volume",
        "language_label": "Langue",
        "back_button": "Retour",
        "Українська": "Ukrainien",
        "English": "Anglais",
        "Русский": "Russe",
        "Polski": "Polonais",
        "Deutsch": "Allemand",
        "Français": "Français",
        "Español": "Espagnol",
        "Italiano": "Italien",
        "中文": "Chinois",
        "日本語": "Japonais",
        "Tiếng Việt": "Vietnamien",
        "हिन्दी": "Hindi",
        "game_over_title": "PARTIE TERMINÉE",
        "restart_button": "Rejouer",
        "return_to_menu_button": "Retour au menu",
        "score_label": "Score"
    },
    "Español": {
        "game_title": "Platformer Rush",
        "start_game_button": "Iniciar Juego",
        "options_button": "Opciones",
        "exit_button": "Salir",
        "game_running_message": "¡Juego en marcha! (Presiona ESC para salir)",
        "settings_title": "Opciones",
        "volume_label": "Volumen",
        "language_label": "Idioma",
        "back_button": "Volver",
        "Українська": "Ucraniano",
        "English": "Inglés",
        "Русский": "Ruso",
        "Polski": "Polaco",
        "Deutsch": "Alemán",
        "Français": "Francés",
        "Español": "Español",
        "Italiano": "Italiano",
        "中文": "Chino",
        "日本語": "Japonés",
        "Tiếng Việt": "Vietnamita",
        "हिन्दी": "Hindi",
        "game_over_title": "JUEGO TERMINADO",
        "restart_button": "De nuevo",
        "return_to_menu_button": "Volver al menú",
        "score_label": "Puntuación"
    },
    "Italiano": {
        "game_title": "Platformer Rush",
        "start_game_button": "Avvia Gioco",
        "options_button": "Opzioni",
        "exit_button": "Esci",
        "game_running_message": "Gioco in esecuzione! (Premi ESC per uscire)",
        "settings_title": "Opzioni",
        "volume_label": "Volume",
        "language_label": "Lingua",
        "back_button": "Indietro",
        "Українська": "Ucraino",
        "English": "Inglese",
        "Русский": "Russo",
        "Polski": "Polacco",
        "Deutsch": "Tedesco",
        "Français": "Francese",
        "Español": "Spagnolo",
        "Italiano": "Italiano",
        "中文": "Cinese",
        "日本語": "Giapponese",
        "Tiếng Việt": "Vietnamita",
        "हिन्दी": "Hindi",
        "game_over_title": "FINE PARTITA",
        "restart_button": "Di nuovo",
        "return_to_menu_button": "Torna al menu",
        "score_label": "Punteggio"
    },
    "中文": {
        "game_title": "跑酷衝刺",
        "start_game_button": "开始游戏",
        "options_button": "设置",
        "exit_button": "退出",
        "game_running_message": "游戏运行中！(按ESC退出)",
        "settings_title": "设置",
        "volume_label": "音量",
        "language_label": "语言",
        "back_button": "返回",
        "Українська": "乌克兰语",
        "English": "英语",
        "Русский": "俄语",
        "Polski": "波兰语",
        "Deutsch": "德语",
        "Français": "法语",
        "Español": "西班牙语",
        "Italiano": "意大利语",
        "中文": "中文",
        "日本語": "日语",
        "Tiếng Việt": "越南语",
        "हिन्दी": "印地语",
        "game_over_title": "游戏结束",
        "restart_button": "再来一次",
        "return_to_menu_button": "返回菜单",
        "score_label": "分数"
    },
    "日本語": {
        "game_title": "プラットフォーマーラッシュ",
        "start_game_button": "ゲーム開始",
        "options_button": "設定",
        "exit_button": "終了",
        "game_running_message": "ゲーム実行中！(ESCで終了)",
        "settings_title": "設定",
        "volume_label": "音量",
        "language_label": "言語",
        "back_button": "戻る",
        "Українська": "ウクライナ語",
        "English": "英語",
        "Русский": "ロシア語",
        "Polski": "ポーランド語",
        "Deutsch": "ドイツ語",
        "Français": "フランス語",
        "Español": "スペイン語",
        "Italiano": "イタリア語",
        "中文": "中国語",
        "日本語": "日本語",
        "Tiếng Việt": "ベトナム語",
        "हिन्दी": "ヒンディー語",
        "game_over_title": "ゲームオーバー",
        "restart_button": "もう一度",
        "return_to_menu_button": "メニューに戻る",
        "score_label": "スコア"
    },
    "Tiếng Việt": {
        "game_title": "Platformer Rush",
        "start_game_button": "Bắt đầu trò chơi",
        "options_button": "Tùy chọn",
        "exit_button": "Thoát",
        "game_running_message": "Trò chơi đang chạy! (Nhấn ESC để thoát)",
        "settings_title": "Tùy chọn",
        "volume_label": "Âm lượng",
        "language_label": "Ngôn ngữ",
        "back_button": "Quay lại",
        "Українська": "Tiếng Ukraina",
        "English": "Tiếng Anh",
        "Русский": "Tiếng Nga",
        "Polski": "Tiếng Ba Lan",
        "Deutsch": "Tiếng Đức",
        "Français": "Tiếng Pháp",
        "Español": "Tiếng Tây Ban Nha",
        "Italiano": "Tiếng Ý",
        "中文": "Tiếng Trung",
        "日本語": "Tiếng Nhật",
        "Tiếng Việt": "Tiếng Việt",
        "हिन्दी": "Tiếng Hindi",
        "game_over_title": "TRÒ CHƠI KẾT THÚC",
        "restart_button": "Chơi lại",
        "return_to_menu_button": "Trở về Menu",
        "score_label": "Điểm"
    },
    "हिन्दी": {
        "game_title": "प्लेटफ़ॉर्मर रश",
        "start_game_button": "गेम शुरू करें",
        "options_button": "विकल्प",
        "exit_button": "बाहर निकलें",
        "game_running_message": "गेम चल रहा है! (बाहर निकलने के लिए ESC दबाएँ)",
        "settings_title": "विकल्प",
        "volume_label": "वॉल्यूम",
        "language_label": "भाषा",
        "back_button": "वापस",
        "Українська": "यूक्रेनी",
        "English": "अंग्रेज़ी",
        "Русский": "रूसी",
        "Polski": "पोलिश",
        "Deutsch": "जर्मन",
        "Français": "फ्रेंच",
        "Español": "स्पेनिश",
        "Italiano": "इतालवी",
        "中文": "चीनी",
        "日本語": "जापानी",
        "Tiếng Việt": "वियतनामी",
        "हिन्दी": "हिन्दी",
        "game_over_title": "गेम ओवर",
        "restart_button": "फिर से",
        "return_to_menu_button": "मेनू पर लौटें",
        "score_label": "स्कोर"
    }
}


# --- Функція для отримання перекладеного тексту ---
def get_translation(lang_key, text_id, translations_dict):
    """
    Повертає перекладений текст за ключем мови та ідентифікатором тексту.
    Якщо переклад не знайдено, повертає ідентифікатор тексту.
    """
    return translations_dict.get(lang_key, {}).get(text_id, text_id)

# --- Глобальні змінні для налаштувань ---
current_volume = 0.5
pygame.mixer.music.set_volume(current_volume)
current_language = "Українська"

# Список доступних мов (ключі верхнього рівня з TRANSLATIONS)
languages = list(TRANSLATIONS.keys())

# --- Функції для відображення тексту та кнопок (для main.py) ---
def draw_text(text, font_obj, color, x, y, center=False):
    text_surface = font_obj.render(text, True, color)
    text_rect = text_surface.get_rect()
    if center:
        text_rect.center = (x, y)
    else:
        text_rect.topleft = (x, y)
    SCREEN.blit(text_surface, text_rect)
    return text_rect

# ОНОВЛЕНА ФУНКЦІЯ draw_button (для main.py)
def draw_button(text, font_obj, x, y, width, height, normal_image_url, hover_image_url, pressed_image_url):
    button_rect = pygame.Rect(x, y, width, height)
    mouse_pos = pygame.mouse.get_pos()
    clicked = pygame.mouse.get_pressed()[0]

    current_image = None
    text_offset_y = 0 # Зміщення тексту для ефекту натискання

    is_hovering = button_rect.collidepoint(mouse_pos)
    
    try:
        if is_hovering:
            if clicked:
                current_image = pygame.image.load(pressed_image_url).convert_alpha()
                text_offset_y = BUTTON_CLICK_OFFSET # Зміщуємо текст вниз при натисканні
            else:
                current_image = pygame.image.load(hover_image_url).convert_alpha()
        else:
            current_image = pygame.image.load(normal_image_url).convert_alpha()
        
        # Масштабуємо зображення під розмір кнопки
        current_image = pygame.transform.scale(current_image, (width, height))
        
        # Якщо кнопка натиснута, зміщуємо її трохи вниз для візуального ефекту
        if is_hovering and clicked:
            SCREEN.blit(current_image, (button_rect.x + BUTTON_CLICK_OFFSET, button_rect.y + BUTTON_CLICK_OFFSET))
        else:
            SCREEN.blit(current_image, button_rect)

    except pygame.error as e:
        print(f"Помилка завантаження зображення кнопки: {e}. Використовую резервний колір.")
        # Резервний варіант, якщо зображення не завантажилось
        current_color = BUTTON_IMAGE_NORMAL
        if is_hovering:
            current_color = BUTTON_IMAGE_HOVER
            if clicked:
                current_color = BUTTON_IMAGE_PRESSED
                text_offset_y = BUTTON_CLICK_OFFSET
        pygame.draw.rect(SCREEN, current_color, button_rect, border_radius=BUTTON_BORDER_RADIUS)
        # Малюємо тінь, якщо використовується резервний колір
        shadow_rect = pygame.Rect(x + BUTTON_SHADOW_OFFSET, y + BUTTON_SHADOW_OFFSET, width, height)
        pygame.draw.rect(SCREEN, BUTTON_SHADOW_COLOR, shadow_rect, border_radius=BUTTON_BORDER_RADIUS)


    # Малюємо текст кнопки поверх зображення
    draw_text(text, font_obj, BUTTON_TEXT_COLOR, button_rect.centerx, button_rect.centery + text_offset_y, center=True)
    
    return button_rect, is_hovering and clicked

# --- Функція Game Over Screen ---
def game_over_screen(final_score):
    draw_text(f"{int(final_score)} м", SMALL_FONT, WHITE, 30, 30)
    global current_language
    game_over_running = True

    # Завантаження фонового зображення для Game Over (можна використовувати BACKGROUND_GAME_IMAGE або інше)
    background_image = None
    try:
        background_image = pygame.image.load(BACKGROUND_GAME_IMAGE).convert() # Або інше зображення
        background_image = pygame.transform.scale(background_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
    except pygame.error as e:
        print(f"Помилка завантаження фону Game Over: {e}. Використовую резервний колір.")
        background_image = None

    while game_over_running:
        # Малюємо фон
        if background_image:
            SCREEN.blit(background_image, (0, 0))
        else:
            SCREEN.fill(BLACK) # Резервний колір


        translated_game_over_title = get_translation(current_language, "game_over_title", TRANSLATIONS)
        translated_restart_button = get_translation(current_language, "restart_button", TRANSLATIONS)
        translated_return_to_menu_button = get_translation(current_language, "return_to_menu_button", TRANSLATIONS)
        translated_score_label = get_translation(current_language, "score_label", TRANSLATIONS)

        draw_text(translated_game_over_title, FONT, RED, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 4, center=True)
        draw_text(f"{translated_score_label}: {final_score}", SMALL_FONT, WHITE, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 4 + 60, center=True)


        # Використовуємо стилізовані кнопки
        restart_button_rect, _ = draw_button(translated_restart_button, FONT, SCREEN_WIDTH // 2 - 150, SCREEN_HEIGHT // 2, 300, 70, BUTTON_IMAGE_NORMAL, BUTTON_IMAGE_HOVER, BUTTON_IMAGE_PRESSED)
        return_to_menu_button_rect, _ = draw_button(translated_return_to_menu_button, FONT, SCREEN_WIDTH // 2 - 150, SCREEN_HEIGHT // 2 + 100, 300, 70, BUTTON_IMAGE_NORMAL, BUTTON_IMAGE_HOVER, BUTTON_IMAGE_PRESSED)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if restart_button_rect.collidepoint(event.pos):
                        return "restart"
                    if return_to_menu_button_rect.collidepoint(event.pos):
                        return "menu"
        
        pygame.display.flip()
        pygame.time.Clock().tick(FPS)

# --- Функція головної гри ---
def run_game():
    distance = 0  # Пройдений шлях
    global current_language
    game_running = True
    clock = pygame.time.Clock()
    world_shift = 0

    # --- Ініціалізація гравця, платформ, ворогів, фону ---
    player = Player(100, SCREEN_HEIGHT - 200)
    platforms = pygame.sprite.Group()
    main_platform = Platform(0, SCREEN_HEIGHT - 40, SCREEN_WIDTH, 40)
    platforms.add(main_platform)
    platforms.add(Platform(200, SCREEN_HEIGHT - 150, 200, 20))
    platforms.add(Platform(500, SCREEN_HEIGHT - 250, 200, 20))
    platforms.add(Platform(100, SCREEN_HEIGHT - 350, 150, 20))

    enemies = pygame.sprite.Group()
    enemies.add(Enemy(300, SCREEN_HEIGHT - 70, 100))
    enemies.add(Enemy(600, SCREEN_HEIGHT - 280, 80))

    background_image = None
    try:
        background_image = pygame.image.load(BACKGROUND_GAME_IMAGE).convert()
        background_image = pygame.transform.scale(background_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
    except pygame.error:
        background_image = None

    platform_spawn_x = 800
    min_platform_gap = 150
    max_platform_gap = 300

    while game_running:
        # --- Обробка подій ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return  # Повертає у головне меню
                if event.key == pygame.K_SPACE or event.key == pygame.K_UP:
                    player.jump()

        # --- Обробка руху ---
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            player.move_left()
        elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            player.move_right()
        else:
            player.stop_move()

        # --- ПРОКРУТКА СВІТУ ---
        if player.rect.right > SCREEN_WIDTH * 2 // 3:
            shift = player.rect.right - SCREEN_WIDTH * 2 // 3
            player.rect.right = SCREEN_WIDTH * 2 // 3
            world_shift -= shift
            distance += shift
            for platform in platforms:
                platform.rect.x -= shift
            for enemy in enemies:
                enemy.rect.x -= shift
                enemy.left_limit -= shift
                enemy.right_limit -= shift
            platform_spawn_x -= shift
        else:
            shift = 0

        # --- Оновлення персонажа ---
        game_status = player.update(platforms)

        # --- Перевірка зіткнень з ворогами ---
        for enemy in enemies:
            if player.collision_rect.colliderect(enemy.rect):
                game_status = "game_over"
                break
            enemy.update(0)

        # --- Генерація нових платформ та ворогів ---
        while platform_spawn_x < SCREEN_WIDTH + abs(world_shift) + 400:
            plat_width = random.randint(100, 200)
            plat_height = 20
            plat_x = platform_spawn_x
            plat_y = random.randint(SCREEN_HEIGHT // 2, SCREEN_HEIGHT - 100)
            new_platform = Platform(plat_x, plat_y, plat_width, plat_height)
            platforms.add(new_platform)

            if random.random() < 0.5:
                enemy_x = plat_x + plat_width // 2
                enemy_left = plat_x
                enemy_right = plat_x + plat_width - 40
                enemy = Enemy(enemy_x, plat_y - 40, enemy_right - enemy_left, left_limit=enemy_left, right_limit=enemy_right)
                enemies.add(enemy)

            platform_spawn_x += random.randint(min_platform_gap, max_platform_gap)

        # --- Видалення старих платформ та ворогів ---
        for platform in list(platforms):
            if platform.rect.right < -200:
                platforms.remove(platform)
        for enemy in list(enemies):
            if enemy.rect.right < -200:
                enemies.remove(enemy)

        # --- Перевірка Game Over ---
        if game_status == "game_over":
            print("Гра закінчена!")
            action = game_over_screen(int(distance))
            if action == "restart":
                return run_game()
            elif action == "menu":
                game_running = False

        # --- Малювання ---
        if background_image:
            SCREEN.blit(background_image, (0, 0))
        else:
            SCREEN.fill(BLACK)

        for platform in platforms:
            platform.draw(SCREEN)
        for enemy in enemies:
            enemy.draw(SCREEN)
        player.draw(SCREEN)

        # Малюємо лічильник шляху
        draw_text(f"{int(distance)} м", SMALL_FONT, WHITE, 30, 30)

        pygame.display.flip()
        clock.tick(FPS)

def main_menu():
    global current_volume, current_language
    menu_running = True

    background_image = None
    try:
        background_image = pygame.image.load(BACKGROUND_MENU_IMAGE).convert()
        background_image = pygame.transform.scale(background_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
    except pygame.error as e:
        print(f"Помилка завантаження фону меню: {e}. Використовую резервний колір.")
        background_image = None

    while menu_running:
        # Малюємо фон
        if background_image:
            SCREEN.blit(background_image, (0, 0))
        else:
            SCREEN.fill(BLACK)

        translated_title = get_translation(current_language, "game_title", TRANSLATIONS)
        translated_start_button = get_translation(current_language, "start_game_button", TRANSLATIONS)
        translated_options_button = get_translation(current_language, "options_button", TRANSLATIONS)
        translated_exit_button = get_translation(current_language, "exit_button", TRANSLATIONS)

        draw_text(translated_title, FONT, WHITE, SCREEN_WIDTH // 2, 100, center=True)

        start_button_rect, _ = draw_button(translated_start_button, FONT, SCREEN_WIDTH // 2 - 150, 250, 300, 70, BUTTON_IMAGE_NORMAL, BUTTON_IMAGE_HOVER, BUTTON_IMAGE_PRESSED)
        options_button_rect, _ = draw_button(translated_options_button, FONT, SCREEN_WIDTH // 2 - 150, 350, 300, 70, BUTTON_IMAGE_NORMAL, BUTTON_IMAGE_HOVER, BUTTON_IMAGE_PRESSED)
        exit_button_rect, _ = draw_button(translated_exit_button, FONT, SCREEN_WIDTH // 2 - 150, 450, 300, 70, BUTTON_IMAGE_NORMAL, BUTTON_IMAGE_HOVER, BUTTON_IMAGE_PRESSED)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                menu_running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if start_button_rect.collidepoint(event.pos):
                        run_game()
                    elif options_button_rect.collidepoint(event.pos):
                        current_volume, current_language = run_menu(SCREEN, current_volume, current_language, languages, TRANSLATIONS)
                    elif exit_button_rect.collidepoint(event.pos):
                        menu_running = False

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main_menu()