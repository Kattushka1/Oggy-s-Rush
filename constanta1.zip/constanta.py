# constanta.py
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# Кольори (можуть бути використані як резервні або для інших елементів)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
DARK_GRAY = (100, 100, 100)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BROWN = (139, 69, 19) # Для платформ
ENEMY_COLOR = RED # Резервний колір для ворогів, якщо зображення не завантажиться

# Налаштування персонажа Oggy
PLAYER_WIDTH = 90
PLAYER_HEIGHT = 90
PLAYER_SPEED = 5
PLAYER_JUMP_STRENGTH = 15
PLAYER_COLOR = BLUE # Резервний колір для персонажа
PLAYER_IMAGE = 'oggy.png'

# Анімації персонажа
PLAYER_IDLE_IMAGE = 'oggy.png'        # Статичне зображення
PLAYER_RUN_IMAGES = ['oggy_1.png', 'oggy_2.png']  # Анімація бігу
ANIMATION_SPEED = 8  # Швидкість анімації (кадрів гри на один кадр анімації, менше = швидше)

# Налаштування ворогів (Таргани)
ENEMY_WIDTH = 50
ENEMY_HEIGHT = 30
ENEMY_SPEED = 2
ENEMY_IMAGE = 'cockaraches.png'  # Зображення ворога

# Фізичні параметри
GRAVITY = 0.8
FPS = 60

# --- URL-адреси зображень ---
# Замініть ці URL на шляхи до ваших власних файлів зображень!
# Наприклад: "assets/button_normal.png"
# Для демонстрації використовую placehold.co
BUTTON_IMAGE_NORMAL = "normal.png" # Сірий
BUTTON_IMAGE_HOVER = "hover.png" # Блакитний
BUTTON_IMAGE_PRESSED = "pressed.png" # Темно-синій

# Шляхи до зображень ворога (анімація)
ENEMY_RUN_IMAGES = [
    'cockaraches.png',
    # Додайте сюди всі ваші кадри для бігу таргана
]

# Константа для швидкості анімації (скільки кадрів гри до зміни кадру анімації)
ANIMATION_SPEED = 10 # Змінюйте це число, щоб пришвидшити або сповільнити анімацію

BACKGROUND_MENU_IMAGE = "gm.png" #Синій фон меню
BACKGROUND_SETTINGS_IMAGE = "settings.png" # Темно-синій фон налаштувань
BACKGROUND_GAME_IMAGE = "game.png" # Світло-блакитний фон гри

MUSIC_FILE = 'byte-blast-8-bit.mp3'

# Ці константи для тіні та закруглення використовуються як резервний варіант
BUTTON_SHADOW_COLOR = (40, 70, 100)
BUTTON_BORDER_RADIUS = 10
BUTTON_SHADOW_OFFSET = 4
BUTTON_CLICK_OFFSET = 2
BUTTON_TEXT_COLOR = WHITE

# Налагодження
DEBUG_COLLISION_RECT = False  # Показувати collision_rect для налагодження
