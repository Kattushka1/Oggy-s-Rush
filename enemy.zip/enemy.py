# enemy.py
import pygame
import random
from constanta import ENEMY_IMAGE, ENEMY_WIDTH, ENEMY_HEIGHT, ENEMY_SPEED, RED # Імпортуємо необхідні константи

class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y, move_range):
        super().__init__()
        try:
            self.image = pygame.image.load(ENEMY_IMAGE).convert_alpha() # Завантажуємо зображення ворога
            self.image = pygame.transform.scale(self.image, (ENEMY_WIDTH, ENEMY_HEIGHT)) # Масштабуємо зображення
        except pygame.error as e:
            print(f"Помилка завантаження зображення ворога: {e}. Використовую резервний колір.") # Вивід помилки
            self.image = pygame.Surface((ENEMY_WIDTH, ENEMY_HEIGHT)) # Створення резервної поверхні
            self.image.fill(RED) # Заповнення резервним кольором

        self.rect = self.image.get_rect(topleft=(x, y)) # Отримання прямокутника зображення
        self.start_x = x # Початкова позиція для визначення діапазону руху
        self.end_x = x + move_range # Кінцева позиція діапазону руху
        self.speed = ENEMY_SPEED # Швидкість ворога
        self.direction = 1 # 1 для руху вправо, -1 для руху вліво

    def update(self, dx):
        # Оновлення позиції з урахуванням зсуву екрану
        self.rect.x += self.speed * self.direction # Рух відносно його локального діапазону

        # Зміщення діапазону руху ворога разом з прокруткою екрану
        self.start_x += dx
        self.end_x += dx

        # Перевірка меж діапазону руху та зміна напрямку
        if self.direction == 1 and self.rect.right >= self.end_x:
            self.direction = -1 # Зміна напрямку на лівий
        elif self.direction == -1 and self.rect.left <= self.start_x:
            self.direction = 1 # Зміна напрямку на правий

    def draw(self, screen):
        screen.blit(self.image, self.rect) # Малюємо ворога на екрані