import pygame

class AudioManager:
    def __init__(self):
        pygame.mixer.init()
        print("Pygame mixer ініціалізовано.")
        self.current_music = None

    def load_music(self, file_path):
        try:
            pygame.mixer.music.load(file_path)
            self.current_music = file_path
            print(f"Музика '{file_path}' завантажена.")
            return True
        except pygame.error as e:
            print(f"Помилка завантаження музики '{file_path}': {e}")
            print("Переконайтеся, що файл музики існує і шлях вірний.")
            self.current_music = None
            return False

    def play_music(self, loops=-1, start=0.0):
        if self.current_music:
            pygame.mixer.music.play(loops, start)
            print(f"Музика '{self.current_music}' відтворюється.")
        else:
            print("Немає завантаженої музики для відтворення.")

    def set_music_volume(self, volume):
        """Встановлює гучність музики (від 0.0 до 1.0)."""
        pygame.mixer.music.set_volume(volume)
        print(f"Гучність музики встановлено на {volume*100:.0f}%.")

    def stop_music(self):
        pygame.mixer.music.stop()
        print("Музика зупинена.")

    def pause_music(self):
        pygame.mixer.music.pause()
        print("Музика на паузі.")

    def unpause_music(self):
        pygame.mixer.music.unpause()
        print("Музика відновлена.")

    # Можна додати методи для звукових ефектів тут же
    def play_sound(self, sound_file_path, volume=1.0):
        try:
            sound = pygame.mixer.Sound(sound_file_path)
            sound.set_volume(volume)
            sound.play()
            print(f"Звук '{sound_file_path}' відтворено.")
            return True
        except pygame.error as e:
            print(f"Помилка завантаження або відтворення звуку '{sound_file_path}': {e}")
            return False
