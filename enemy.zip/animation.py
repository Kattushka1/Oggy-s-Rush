import pygame

pygame.init()

screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Платформер з анімацією")

# --- Завантаження спрайтів для анімації ---
# Припустимо, у вас є папки 'player/idle' та 'player/run' з зображеннями
def load_animation_frames(path_prefix, num_frames):
    frames = []
    for i in range(num_frames):
        # Наприклад: 'player/idle/idle_0.png', 'player/idle/idle_1.png'
        filename = f"{path_prefix}/{path_prefix.split('/')[-1]}_{i}.png"
        try:
            img = pygame.image.load(filename).convert_alpha()
            frames.append(img)
        except pygame.error as e:
            print(f"Помилка завантаження кадру '{filename}': {e}")
            return []
    return frames

# Завантажуємо анімації
idle_frames = load_animation_frames('player/idle', 4) # Припустимо 4 кадри для 'idle'
run_frames = load_animation_frames('player/run', 6)   # Припустимо 6 кадрів для 'run'

# --- Параметри гравця ---
player_x = 100
player_y = 400
player_speed = 5

# --- Параметри анімації ---
current_animation = idle_frames
current_frame_index = 0
animation_timer = 0
animation_speed = 0.1 # Чим менше значення, тим швидше анімація (секунд на кадр)

# Додатково для перевертання спрайта
facing_right = True

clock = pygame.time.Clock()
running = True

while running:
    dt = clock.tick(60) / 1000.0 # Час, що минув з останнього кадру в секундах (для незалежності від FPS)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # --- Оновлення гравця та анімації ---
    keys = pygame.key.get_pressed()
    moving = False

    if keys[pygame.K_LEFT]:
        player_x -= player_speed
        current_animation = run_frames
        facing_right = False
        moving = True
    elif keys[pygame.K_RIGHT]:
        player_x += player_speed
        current_animation = run_frames
        facing_right = True
        moving = True
    else:
        current_animation = idle_frames # Якщо не рухаємося, повертаємося до анімації простою
        moving = False

    # Оновлення кадру анімації
    animation_timer += dt
    if animation_timer >= animation_speed:
        animation_timer = 0
        current_frame_index = (current_frame_index + 1) % len(current_animation)
        # % len(current_animation) забезпечує зациклення анімації

    # --- Малювання ---
    screen.fill((0, 0, 0)) # Чорний фон

    if current_animation:
        # Отримуємо поточний кадр
        current_frame = current_animation[current_frame_index]

        # Перевертаємо кадр, якщо персонаж дивиться вліво
        if not facing_right:
            current_frame = pygame.transform.flip(current_frame, True, False) # flip(surface, x_bool, y_bool)

        # Малюємо гравця
        screen.blit(current_frame, (player_x, player_y))
    else:
        print("Немає кадрів для відтворення анімації!")

    pygame.display.flip()

pygame.quit()