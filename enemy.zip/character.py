import pygame
from constanta import *

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        # Головний прямокутник для відображення (повний розмір спрайту)
        self.rect = pygame.Rect(x, y, PLAYER_WIDTH, PLAYER_HEIGHT)
        
        # Менший прямокутник для колізії (70% від розміру спрайту)
        collision_width = int(PLAYER_WIDTH * 0.7)
        collision_height = int(PLAYER_HEIGHT * 0.7)
        offset_x = (PLAYER_WIDTH - collision_width) // 2
        offset_y = (PLAYER_HEIGHT - collision_height) // 2
        self.collision_rect = pygame.Rect(x + offset_x, y + offset_y, collision_width, collision_height)
        
        # Завантаження зображень для анімації
        self.load_animations()
        
        # Параметри анімації
        self.current_animation = self.idle_image
        self.animation_frame = 0
        self.animation_counter = 0
        self.facing_right = True
        self.is_moving = False
        
        # Фізичні параметри
        self.vel_x = 0
        self.vel_y = 0
        self.on_ground = False

    def load_animations(self):
        """Завантаження всіх зображень для анімації"""
        # Завантаження статичного зображення (idle)
        try:
            self.idle_image = pygame.image.load(PLAYER_IDLE_IMAGE).convert_alpha()
            self.idle_image = pygame.transform.scale(self.idle_image, (PLAYER_WIDTH, PLAYER_HEIGHT))
        except pygame.error:
            self.idle_image = pygame.Surface((PLAYER_WIDTH, PLAYER_HEIGHT))
            self.idle_image.fill(PLAYER_COLOR)
        
        # Завантаження кадрів для анімації бігу
        self.run_images = []
        for image_path in PLAYER_RUN_IMAGES:
            try:
                img = pygame.image.load(image_path).convert_alpha()
                img = pygame.transform.scale(img, (PLAYER_WIDTH, PLAYER_HEIGHT))
                self.run_images.append(img)
            except pygame.error:
                # Якщо зображення не завантажилось, створюємо кольорову поверхню
                img = pygame.Surface((PLAYER_WIDTH, PLAYER_HEIGHT))
                img.fill(PLAYER_COLOR)
                self.run_images.append(img)
        
        # Якщо немає зображень для бігу, використовуємо idle
        if not self.run_images:
            self.run_images = [self.idle_image]
        
        # Встановлюємо поточне зображення
        self.image = self.idle_image

    def update_animation(self):
        """
        Оновлення анімації персонажа
        - При русі відтворюється анімація з oggy_1.png та oggy_2.png по черзі
        - При зупинці показується статичне зображення oggy.png  
        - Зображення автоматично відзеркалюється при русі вліво
        """
        self.animation_counter += 1
        
        if self.is_moving:
            # Анімація бігу - змінюємо кадри через кожні ANIMATION_SPEED ігрових кадрів
            if self.animation_counter >= ANIMATION_SPEED:
                self.animation_counter = 0
                self.animation_frame = (self.animation_frame + 1) % len(self.run_images)
            self.current_animation = self.run_images[self.animation_frame]
        else:
            # Статичне зображення коли персонаж не рухається
            self.current_animation = self.idle_image
            self.animation_frame = 0
            self.animation_counter = 0  # Скидаємо лічильник при зупинці
        
        # Застосування поточного зображення з урахуванням напрямку
        if self.facing_right:
            self.image = self.current_animation
        else:
            # Відзеркалюємо зображення для руху вліво
            self.image = pygame.transform.flip(self.current_animation, True, False)

    def move_left(self):
        self.vel_x = -PLAYER_SPEED
        self.facing_right = False
        self.is_moving = True

    def move_right(self):
        self.vel_x = PLAYER_SPEED
        self.facing_right = True
        self.is_moving = True

    def stop_move(self):
        self.vel_x = 0
        self.is_moving = False

    def jump(self):
        if self.on_ground:
            self.vel_y = -PLAYER_JUMP_STRENGTH
            self.on_ground = False

    def update(self, platforms):
        # Оновлення анімації
        self.update_animation()
        
        # Рух по горизонталі
        self.rect.x += self.vel_x
        self.collision_rect.centerx = self.rect.centerx
        
        # Перевірка горизонтальних колізій
        for platform in platforms:
            if self.collision_rect.colliderect(platform.rect):
                if self.vel_x > 0:  # Рухаємося вправо
                    self.collision_rect.right = platform.rect.left
                    self.rect.centerx = self.collision_rect.centerx
                elif self.vel_x < 0:  # Рухаємося вліво
                    self.collision_rect.left = platform.rect.right
                    self.rect.centerx = self.collision_rect.centerx
        
        # Застосовуємо гравітацію
        self.vel_y += GRAVITY
        self.rect.y += self.vel_y
        self.collision_rect.centery = self.rect.centery
        
        # Перевірка вертикальних колізій
        self.on_ground = False
        for platform in platforms:
            if self.collision_rect.colliderect(platform.rect):
                if self.vel_y > 0:  # Падаємо вниз
                    self.collision_rect.bottom = platform.rect.top
                    self.rect.centery = self.collision_rect.centery
                    self.vel_y = 0
                    self.on_ground = True
                elif self.vel_y < 0:  # Стрибаємо вгору
                    self.collision_rect.top = platform.rect.bottom
                    self.rect.centery = self.collision_rect.centery
                    self.vel_y = 0
        
        # Перевіряємо чи не падає за межі екрану
        if self.rect.top > SCREEN_HEIGHT:
            return "game_over"
        
        # Обмеження по краях екрану
        if self.rect.left < 0:
            self.rect.left = 0
            self.collision_rect.centerx = self.rect.centerx
        if self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
            self.collision_rect.centerx = self.rect.centerx
            
        return "playing"

    def draw(self, screen):
        screen.blit(self.image, self.rect)
        # ВІДЛАГОДЖЕННЯ: малюємо прямокутник колізії (можна вимкнути)
        # pygame.draw.rect(screen, (255, 255, 0), self.collision_rect, 2)  # Жовта рамка

# Клас Player видалено - логіка персонажа більше не потрібна

class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y, move_range, left_limit=None, right_limit=None):
        super().__init__()
        self.rect = pygame.Rect(x, y, ENEMY_WIDTH, ENEMY_HEIGHT)
        self.direction = -1  # -1 для руху справа наліво (на героя)
        self.speed = ENEMY_SPEED

        # Межі руху ворога (по платформі)
        self.left_limit = left_limit if left_limit is not None else x - move_range // 2
        self.right_limit = right_limit if right_limit is not None else x + move_range // 2

        # --- Додаємо ініціалізацію зображення ворога ---
        try:
            self.image = pygame.image.load(ENEMY_IMAGE).convert_alpha()
            self.image = pygame.transform.scale(self.image, (ENEMY_WIDTH, ENEMY_HEIGHT))
        except pygame.error:
            self.image = pygame.Surface((ENEMY_WIDTH, ENEMY_HEIGHT))
            self.image.fill(ENEMY_COLOR)

    def update(self, scroll_amount):
        self.rect.x += self.direction * self.speed
        if self.rect.x <= self.left_limit or self.rect.x >= self.right_limit:
            self.direction *= -1
        self.rect.x += scroll_amount

    def draw(self, screen):
        screen.blit(self.image, self.rect)
